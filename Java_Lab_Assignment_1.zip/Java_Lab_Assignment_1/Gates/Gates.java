/*
Harshith R
211039004
*/

//Implement a gates(AND,OR,NOT,NOR,XOR,NAND) using JAVA

public class Gates
{
	public static void main(String[] args) 
	{
		int option = 0;
		System.out.println("Enter the option: \n1. AND \n2. OR\n3. NOT\n4. NOR\n5. XOR\n6. NAND\n\nSelection: ");
		GateLogic g = new GateLogic();

		// g.and(true, false);
		 g.or(true, false);
		// g.xor(1, 0);
		// g.not(0);
		// g.nand(1, 0);
		// g.nor(1, 0);
	}
}