public class GateLogic
{
	boolean bit1, bit2;

	public void and(boolean b1, boolean b2)
	{
		bit1 = b1;
		bit2 = b2;

		System.out.println("AND of "+b1+" AND "+b2+" is: "+(b1&b2));
	}

	public void or(boolean b1, boolean b2)
	{
		bit1 = b1;
		bit2 = b2;

		System.out.println("AND of "+b1+" OR "+b2+" is: "+(b1|b2));
	}
}
