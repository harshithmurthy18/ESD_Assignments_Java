import  java.util.*;

interface IntFullAdder
{
	void DisplaySumAndCarry(int x, int y, int z);
}

class FullAdderClass implements IntFullAdder
{
	int sum, carry;
	public void DisplaySumAndCarry(int a, int b, int cin)
	{
		System.out.println("Sum is: "+(sum = a^b^cin));
		System.out.println("Carry is: "+(carry = a&b | b&cin | cin&a));
	}
}

class FullAdder
{
	public static void main(String[] args) 
	{
		int a, b, cin;
		Scanner sc = new Scanner(System.in);
		FullAdderClass obj = new FullAdderClass();

		System.out.println("Enter the value of a: ");
		a = sc.nextInt();

		System.out.println("Enter the value of b: ");
		b = sc.nextInt();

		System.out.println("Enter the value of cin: ");
		cin = sc.nextInt();

		obj.DisplaySumAndCarry(a,b,cin);
	}
}