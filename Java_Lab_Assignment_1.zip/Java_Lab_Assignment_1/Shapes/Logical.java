import java.util.Scanner; 

public class Logical 
{
public static void main(String[] args)
{
Scanner num = new Scanner(System.in);
int a1, b1;
System.out.print("Enter the first bit\n");
a1=num.nextInt();
System.out.print("Enter the another bit\n");
b1= num.nextInt();

System.out.println("Enter the Choice 1 for or, 2 for and,3 for xor,4 for nand,5 for nor, :\n");
int choice = num.nextInt();

Logical lg = new Logical();

switch(choice)
	{
	case 1:
		lg.or(a1,b1);
		break;
	case 2:
		lg.and(a1,b1);
		break;
	case 3:
		lg.xor(a1,b1);
		break;
	case 4:
		lg.nand(a1,b1);
		break;	
	case 5:
		lg.nor(a1,b1);	
		break;
	default: 
	    System.out.println("incorrect choice\n");
	    break;
	}

}
public void or(int a, int b)
{
	int orr= a+b;
	if(orr >= 2)
	{
		orr=1;
	}
	System.out.print("OR\n"+orr);

}
public void and(int a, int b)
{
	int andd= a*b;
System.out.print("AND\n"+andd);
}

public void xor(int a, int b)
{
	int xorr= a+b;
	if(xorr >= 2)
	{
		xorr=0;
	}
	System.out.print("XOR\n"+xorr);


}
public void nand(int a, int b)
{
	int nandd= a*b;
	if(nandd >= 2)
	{
		nandd=0;
	}
	else
	{
		nandd=1;
	}
	System.out.print("NAND\n"+nandd);


}
public void nor(int a, int b)
{
	int norr= a+b;
	if(norr ==0)
	{
		norr=1;
	}
	else
	{
		norr=0;
	}
	System.out.print("nor\n"+norr);

}


