import java.util.*;
import java.lang.Math;

interface Shape {
	int area();
}

interface Shape1 {
	double area2();
}

class Square implements Shape{
  public int area()
	   {
			int a;
			System.out.println("value of side");
			Scanner sq = new Scanner(System.in);
			a=sq.nextInt();
			int area1= a*a;
			return area1;
	   }
 }
 class Rectangle implements Shape{
  public int area()
	   {
	   	int a,b;
			Scanner sq = new Scanner(System.in);
			System.out.println("value of side1\n");
			a=sq.nextInt();
			System.out.println("value of side2\n");
			b=sq.nextInt();
			int area1= a*b;
			return area1;
	   }
 }
 class Traingle implements Shape1{
  public double area2()
	   {
			int l,b;
			Scanner sq = new Scanner(System.in);
			System.out.println("value of l");
			l=sq.nextInt();
			System.out.println("value of b");
			b=sq.nextInt();
			double area1= 0.5*l*b;
			return area1;
	   }
 }
 class Circle implements Shape1{
  public double area2()
	   {
			int r;
			System.out.println("value of r");
			Scanner sq = new Scanner(System.in);
			r=sq.nextInt();
			double area1= Math.PI*Math.pow(r,2);
			return area1;
	   }
 }



 class geometrical {
 	
 public static void main(String[] args) 
 {
 	int sqarea,recarea;
 	double triarea;
 	double cirarea;
	Scanner num = new Scanner(System.in);
	System.out.println("Enter the Choice 1 for square, 2 for rectangle,3 for traingle,4 for circle :\n");
	int choice = num.nextInt();
	switch(choice)
	{
		case 1:
		 {     
				 	Shape sh =new Square();
				  sqarea= sh.area();
				   System.out.println("Area of the square"+sqarea);
				   break;
		 }
		case 2:
		  {
			  	Shape sh =new Rectangle();
			   recarea= sh.area();
			    System.out.println("Area of the rectangle"+recarea);
			    break;
		  }
		case 3:
			 {
			 	Shape1 sh =new Traingle();
			  triarea= sh.area2();
			  System.out.println("Area of the traingle"+triarea);
			  break;
		 }
		case 4:
		 {
			 	Shape1 sh =new Circle();
			  cirarea= sh.area2();
			  System.out.println("Area of the circle "+cirarea);
			  break;
		 }
	  }
	}  
}
